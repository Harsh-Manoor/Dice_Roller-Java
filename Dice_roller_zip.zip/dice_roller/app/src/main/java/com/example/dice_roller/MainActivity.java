package com.example.dice_roller;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView dice_image;
    Button button;
    Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dice_image = findViewById(R.id.dice_image);
        button = findViewById(R.id.button);

        dice_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rotateDice();
                
            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rotateDice();
            }
        });
    }

    private void rotateDice() {
        int i = random.nextInt(5)+1;

        switch (i){
            case 1:
                dice_image.setImageResource(R.drawable.dice_one);
                break;
            case 2:
                dice_image.setImageResource(R.drawable.dice_two);
                break;
            case 3:
                dice_image.setImageResource(R.drawable.dice_three);
                break;
            case 4:
                dice_image.setImageResource(R.drawable.dice_four);
                break;
            case 5:
                dice_image.setImageResource(R.drawable.dice_five);
                break;
            case 6:
                dice_image.setImageResource(R.drawable.dice_six);
                break;

        }
    }
}